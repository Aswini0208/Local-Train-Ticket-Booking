<html>
<head>
</head>
<body style="background-color: F5F1F0;">
<table border = 1>
<?php

for($num=0; $num<10;$num++) 
{
echo '<tr><td>'.$num.'</td></tr>' ;


}
?>
</table>
<h1>workshop</h1>
</body style="background-color: F5F1F0;">
</html>
