LOCAL TRAIN TICKET BOOKING USING PHP

Hi Guys My name is Prasath M and My Project Title is LOCAL TRAIN TICKET BOOKING

How to run the project?

step 1:Create A folder name as Local Train Ticket Booking in C:\xampp\htdocs.Paste the all code files in C:\xampp\htdocs\Local Train Ticket Booking.

step 2:Open Xampp and now click start for Apache and mysql.

step 3:Now click the "Admin" button straight to the mysql.

step 4:Now click "new" at the left side of PhpMyAdmin 
.
step 5:Database name as "localtrainticketbookingsystem1" and click create.

step 6:After creating , click import button at the top. 

step 7:Import the sql file named as "epiz_33825522_localtrainticketbookingsystem (1)" and click import and close the tab.

step 8:Open Browser search localhost/Local Train Ticket Booking.

step 9:Now you can see the Website.

step 10:Optional if you want razorpay PaymentGateway mail me i will tell you - iamprasath15@gmail.com


![Screenshot (1417)](https://github.com/Prasathlonelyking/LocalTrainTicketBooking/assets/119600246/a584b88a-c2a4-4a3f-826a-757b41f3f22d)

![Screenshot (1418)](https://github.com/Prasathlonelyking/LocalTrainTicketBooking/assets/119600246/e3dcaf20-b599-4871-a654-db6a89e5a922)

![Screenshot (1419)](https://github.com/Prasathlonelyking/LocalTrainTicketBooking/assets/119600246/62ea1971-5856-42fa-b8fe-215893d03954)

![Screenshot (1420)](https://github.com/Prasathlonelyking/LocalTrainTicketBooking/assets/119600246/8e2ab32b-3e31-4948-8793-0a6874cf5139)

![Screenshot (1421)](https://github.com/Prasathlonelyking/LocalTrainTicketBooking/assets/119600246/8d6c1398-f2ef-43f8-96f8-a8d79e7435ef)

![Screenshot (1422)](https://github.com/Prasathlonelyking/LocalTrainTicketBooking/assets/119600246/7f9f1eb5-d9a5-44d7-adf0-da8fc5808491)

![Screenshot (1423)](https://github.com/Prasathlonelyking/LocalTrainTicketBooking/assets/119600246/cd1f8cb6-6da9-4962-bc83-513daaa1ee35)

![Screenshot (1424)](https://github.com/Prasathlonelyking/LocalTrainTicketBooking/assets/119600246/87278dd7-cf0e-4e12-bd28-df094eb2cad8)


![Screenshot (1425)](https://github.com/Prasathlonelyking/LocalTrainTicketBooking/assets/119600246/24c0f5a3-1539-4a41-a64c-dcb377421d96)

![Screenshot (1426)](https://github.com/Prasathlonelyking/LocalTrainTicketBooking/assets/119600246/e28182cb-6a18-4518-81e6-fbe2efe5c9f4)

![Screenshot (1427)](https://github.com/Prasathlonelyking/LocalTrainTicketBooking/assets/119600246/53458188-2838-40a9-a081-325da1da05cc)
